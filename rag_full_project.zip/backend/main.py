from fastapi import FastAPI, Request, HTTPException, Depends
from fastapi.responses import JSONResponse, RedirectResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import os, uvicorn, json, pickle, pathlib, uuid, time
from typing import List
import faiss
import numpy as np
import openai

# Basic config via environment
OPENAI_API_KEY = os.getenv('OPENAI_API_KEY')
if not OPENAI_API_KEY:
    print('Warning: OPENAI_API_KEY not set. Embedding & generation endpoints will fail until provided.')
else:
    openai.api_key = OPENAI_API_KEY

DATA_DIR = pathlib.Path('data')
DATA_DIR.mkdir(exist_ok=True)
VECTORS_PATH = DATA_DIR / 'vectors.faiss'
METADATA_PATH = DATA_DIR / 'metadata.pkl'

app = FastAPI(title='RAG Chatbot Backend Demo')

# serve frontend static files
app.mount('/', StaticFiles(directory='frontend', html=True), name='frontend')

class IngestRequest(BaseModel):
    doc_id: str
    title: str
    text: str

class QueryRequest(BaseModel):
    question: str
    top_k: int = 4

def ensure_index(dim=1536):
    # 1536 is OpenAI embedding dim (text-embedding-3-small/large may differ)
    if VECTORS_PATH.exists():
        index = faiss.read_index(str(VECTORS_PATH))
    else:
        index = faiss.IndexFlatL2(dim)
    return index

def load_metadata():
    if METADATA_PATH.exists():
        with open(METADATA_PATH,'rb') as f:
            return pickle.load(f)
    return []

def save_metadata(meta):
    with open(METADATA_PATH,'wb') as f:
        pickle.dump(meta,f)

@app.post('/api/ingest')
def ingest(req: IngestRequest):
    """Ingest a document: compute embeddings and add to FAISS index"""
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail='OPENAI_API_KEY not configured')
    # call OpenAI embeddings
    resp = openai.Embedding.create(model='text-embedding-3-small', input=req.text)
    emb = np.array(resp['data'][0]['embedding']).astype('float32')
    index = ensure_index(dim=emb.shape[0])
    if not VECTORS_PATH.exists():
        # create a new persistent index by writing right after add
        index.add(np.array([emb]))
    else:
        index.add(np.array([emb]))
    faiss.write_index(index, str(VECTORS_PATH))
    # metadata
    meta = load_metadata()
    meta.append({'id': req.doc_id, 'title': req.title, 'text': req.text, 'ts': time.time()})
    save_metadata(meta)
    return {'status':'ok', 'indexed': True}

@app.post('/api/query')
def query(req: QueryRequest):
    if not OPENAI_API_KEY:
        raise HTTPException(status_code=500, detail='OPENAI_API_KEY not configured')
    meta = load_metadata()
    if len(meta)==0:
        return {'answer': 'No documents indexed. Ingest documents first.'}
    # embed question
    resp = openai.Embedding.create(model='text-embedding-3-small', input=req.question)
    q_emb = np.array(resp['data'][0]['embedding']).astype('float32')
    index = ensure_index(dim=q_emb.shape[0])
    if index.ntotal == 0:
        return {'answer': 'No vectors found. Ingest documents first.'}
    D, I = index.search(np.array([q_emb]), req.top_k)
    hits = []
    for idx in I[0]:
        if idx < len(meta):
            hits.append(meta[idx])
    # prepare prompt
    context = "\n---\n".join([h['text'] for h in hits])
    prompt = f"You are a helpful assistant. Use the following context to answer the question.\nContext:\n{context}\nQuestion: {req.question}\nAnswer:"
    # call OpenAI completion (ChatCompletion)
    completion = openai.ChatCompletion.create(
        model='gpt-4o-mini', # change to available model in your account
        messages=[{'role':'system','content':'You are a helpful assistant.'},
                  {'role':'user','content':prompt}],
        max_tokens=512,
        temperature=0.2
    )
    answer = completion['choices'][0]['message']['content']
    return {'answer': answer, 'sources': [h['title'] for h in hits]}

@app.get('/api/health')
def health():
    return {'status':'ok'}

if __name__ == '__main__':
    uvicorn.run('main:app', host='0.0.0.0', port=int(os.getenv('PORT', 8000)), reload=True)
