# Backend (FastAPI) — RAG Chatbot Demo

## Overview
This backend provides:
- /api/ingest : POST to index a document (doc_id, title, text)
- /api/query  : POST to query the indexed docs
- Static serving of frontend from /frontend

## Setup (local)
1. Create virtualenv: `python -m venv venv && source venv/bin/activate` (Windows: venv\Scripts\activate)
2. Install requirements: `pip install -r requirements.txt`
3. Set env var: `export OPENAI_API_KEY=sk-...` (or create .env)
4. Run: `python main.py` or `uvicorn main:app --reload --host 0.0.0.0 --port 8000`
5. Open http://localhost:8000/

## Notes
- You must supply a valid `OPENAI_API_KEY` in env for embeddings & generation.
- Google OAuth and Google Drive listing is **not** implemented in this quick backend to avoid complexity; instead ingest documents via `/api/ingest`.
- For production: replace gpt-4o-mini and embedding model with ones available in your OpenAI account and follow security best practices.
