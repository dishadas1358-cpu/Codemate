// Minimal client-side logic to simulate auth, docs listing, selection, and chat responses.
const signinBtn = document.getElementById('signinBtn');
const userInfo = document.getElementById('userInfo');
const docsList = document.getElementById('docsList');
const addDocsBtn = document.getElementById('addDocsBtn');
const chatbox = document.getElementById('chatbox');
const chatForm = document.getElementById('chatForm');
const userInput = document.getElementById('userInput');

let signedIn = false;
let docs = [
  {id:1, title:'Project Proposal — RAG Chatbot', content:'This doc explains the RAG architecture, oauth flow, and retrieval pipeline.'},
  {id:2, title:'Design Notes', content:'Design decisions: Python backend, embeddings, vector DB, simple UI.'},
  {id:3, title:'User Manual', content:'How to sign in, select docs and ask questions to the chatbot.'}
];
let kb = []; // selected docs added to knowledge base

function renderDocs(){
  docsList.innerHTML = '';
  docs.forEach(d=>{
    const div = document.createElement('div');
    div.className = 'doc-item';
    div.innerHTML = `<input type="checkbox" data-id="${d.id}" /> <div><strong>${d.title}</strong><div class="muted small">${d.content.slice(0,80)}...</div></div>`;
    docsList.appendChild(div);
  });
}

signinBtn.addEventListener('click', ()=>{
  signedIn = !signedIn;
  if(signedIn){
    signinBtn.textContent = 'Sign out';
    userInfo.textContent = 'Signed in as: anwesh@example.com (simulated)';
    renderDocs();
    addDocsBtn.disabled = false;
  } else {
    signinBtn.textContent = 'Sign in with Google (simulate)';
    userInfo.textContent = '';
    docsList.innerHTML = '';
    kb = [];
    addDocsBtn.disabled = true;
  }
});

addDocsBtn.addEventListener('click', ()=>{
  const checked = [...document.querySelectorAll('#docsList input[type="checkbox"]:checked')].map(i=>parseInt(i.dataset.id));
  kb = docs.filter(d=>checked.includes(d.id));
  if(kb.length) alert(kb.length + ' document(s) added to local KB (simulated).');
  else alert('No documents selected.');
});

function appendMessage(text, who='bot'){
  const div = document.createElement('div');
  div.className = 'msg ' + (who==='user' ? 'user' : 'bot');
  div.textContent = text;
  chatbox.appendChild(div);
  chatbox.scrollTop = chatbox.scrollHeight;
}

chatForm.addEventListener('submit', (e)=>{
  e.preventDefault();
  const q = userInput.value.trim();
  if(!q) return;
  appendMessage(q, 'user');
  userInput.value = '';
  // simple local retrieval: search kb contents for query keywords
  setTimeout(()=>{
    if(kb.length===0){
      appendMessage('I could not find an answer in your selected documents. Here is a general answer: This demo shows how a RAG chatbot would fallback to its knowledge.', 'bot');
    } else {
      const lower = q.toLowerCase();
      const found = kb.find(d=>d.content.toLowerCase().includes(lower) || d.title.toLowerCase().includes(lower));
      if(found) appendMessage(found.content, 'bot');
      else appendMessage('Answer not found in selected docs. General response: Build a backend RAG pipeline that retrieves embeddings from docs and queries an LLM for answer generation.', 'bot');
    }
  }, 600);
});

// initial render (no auth)
renderDocs();